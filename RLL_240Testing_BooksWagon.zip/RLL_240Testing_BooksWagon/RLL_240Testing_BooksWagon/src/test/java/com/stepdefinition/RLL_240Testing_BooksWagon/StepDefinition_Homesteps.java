package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_Bookswagon.homepage;


import io.cucumber.java.After;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 
public class StepDefinition_Homesteps { 
	WebDriver driver;     
	homepage hp; 
	Logger log;
	ExtentReports extent;
	ExtentTest test;

	@Before 
	public void init() { 
		// Set up ExtentReports
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/HomeReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		driver = new ChromeDriver(); 
		hp = new homepage(driver); 
		log = Logger.getLogger(StepDefinition_Homesteps.class);
	} 

	@Given("user should be in home page1") 
	public void user_should_be_in_home_page1() { 
		hp.launch(); 
		log.info("Browser is launched"); 
		test = extent.createTest("User in Home Page");
		test.pass("User successfully launched the browser and navigated to the home page.");
	} 

	@When("user click on my account") 
	public void user_click_on_my_account() { 
		hp.clickMyAccount(); 
		log.info("Clicked on my account"); 
		test = extent.createTest("Click My Account");
		test.pass("User clicked on the 'My Account' button.");
	} 

	@Then("user should be navigated to the My Account page3") 
	public void user_should_be_navigated_to_the_My_Account_page3() { 
		String expectedUrl = "https://www.bookswagon.com"; // Replace with the actual My Account page URL
		String currentUrl = driver.getCurrentUrl();

		Assert.assertEquals("User is not navigated to the My Account page.", expectedUrl, currentUrl);
		test = extent.createTest("Verify Navigation to My Account");
		test.pass("User successfully navigated to the My Account page.");
	} 

	@After
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // Close the browser
		}
		extent.flush(); // Flush the report
		log.info("Driver closed and extent report flushed.");
	}
}






