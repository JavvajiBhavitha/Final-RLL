package com.stepdefinition.RLL_240Testing_BooksWagon;

import static org.testng.Assert.assertTrue;
import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;
import com.pages.RLL_240Testing_Bookswagon.ForgotPage;
import com.pages.RLL_240Testing_Bookswagon.homepage;
import io.cucumber.java.After;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class StepDefinition_ForgotSteps { 

    WebDriver driver;	 
    ForgotPage fp; 
    homepage hp; 
    Logger log3; 
    ExtentReports extent;
    ExtentTest test;

    @Before 
    public void init() { 
        // Initialize ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/ForgotPage.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        driver = new ChromeDriver(); 
        fp = new ForgotPage(driver); 
        hp = new homepage(driver); 
        log3 = Logger.getLogger(StepDefinition_ForgotSteps.class); 
    } 

    @Given("user should be on the forgot password page") 
    public void user_should_be_on_forgot_password_page() { 
        test = extent.createTest("User should be on the forgot password page");
        hp.launch(); 
        hp.clickMyAccount(); 
        log3.info("User is on the forgot page");
        test.pass("Navigated to forgot password page");
    } 

    @When("^user enters (.*)$") 
    public void user_enters_forgotmoboremail(String fotgotmoboremail) { 
        test = extent.createTest("User enters mobile/email");
        fp.enterForgotMobileEmail(fotgotmoboremail); 
        test.pass("Entered mobile/email: " + fotgotmoboremail);
    } 

    @When("user clicks on continue") 
    public void user_clicks_on_continue() { 
        test = extent.createTest("User clicks on continue");
        fp.clickContinueButton(); 
        test.pass("Clicked on continue button");
    } 
    
    @Then("user should see a status message indicating status")
    public void user_should_see_a_status_message_indicating_status() {
        test = extent.createTest("User should see a status message");
        String currentUrl = driver.getCurrentUrl();
        assertTrue(currentUrl.contains("https://www.bookswagon.com/login#"));
        test.pass("Status message displayed, current URL: " + currentUrl);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
        extent.flush(); // Save the report
    }
}
