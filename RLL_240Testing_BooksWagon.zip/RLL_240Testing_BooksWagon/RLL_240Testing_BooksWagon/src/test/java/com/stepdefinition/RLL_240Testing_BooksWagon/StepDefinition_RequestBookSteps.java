package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.After;
import io.cucumber.java.en.*;
import org.testng.Assert;

import com.pages.RLL_240Testing_Bookswagon.Detalis;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class StepDefinition_RequestBookSteps {
    WebDriver driver;
    Detalis d;
    Logger log; 
    ExtentReports extent;
    ExtentTest test;

    public void init() {
        // Set up ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/RequestBook.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        
        // Initialize WebDriver and page objects
        driver = new ChromeDriver();
        d = new Detalis();
        d.init1(driver); // Initialize WebDriver in Detalis class
        log = Logger.getLogger(Detalis.class);
    }

    @Given("user in login Requestbook page")
    public void user_in_login_Requestbook_page() {
        init();
        driver.get("https://www.bookswagon.com/requestbook");
        
        log.info("User in requestbook page");
        test = extent.createTest("User in Request Book Page");
        test.pass("User navigated to request book page.");
    }

    @When("^the user enter ISBN13 no (.*)$")
    public void the_user_enter_ISBN13_no(String ISBN13no) throws InterruptedException {
        test = extent.createTest("Enter ISBN13 Number");
        d.ISBN13(ISBN13no);
        Thread.sleep(1000);
        test.info("User entered ISBN13 number: " + ISBN13no);
        // log.info("user entered isbn13 number");
    }

    @And("^the user enter Author name (.*)$")
    public void the_user_enter_Author_name(String Authorname) {
        test = extent.createTest("Enter Author Name");
        d.Author(Authorname);
        test.info("User entered Author name: " + Authorname);
    }

    @And("^the user enter Email Id no (.*)$")
    public void the_user_enter_Email_Id_no(String Emaild) {
        test = extent.createTest("Enter Email ID");
        d.emailField1(Emaild);
        test.info("User entered Email ID: " + Emaild);
    }

    @And("click the verify email")
    public void click_the_verify_email() {
        test = extent.createTest("Click Verify Email");
        d.verifyEmailButton();
        test.info("User clicked the verify email button.");
    }

    @And("^the user enter Book Title no (.*)$")
    public void the_user_enter_Book_Title_no(String BookTitle) {
        test = extent.createTest("Enter Book Title");
        d.BookTitle(BookTitle);
        test.info("User entered Book Title: " + BookTitle);
    }

    @And("^the user enter Book Qunatity (.*)$")
    public void the_user_enter_Book_Qunatity(String BookQunatity) {
        test = extent.createTest("Enter Book Quantity");
        d.Quantity(BookQunatity);
        test.info("User entered Book Quantity: " + BookQunatity);
    }

    @And("^the user enter Phone/Mobile (.*)$")
    public void the_user_enter_Phone_Mobile(String Phoneno) {
        test = extent.createTest("Enter Phone/Mobile Number");
        d.phoneNumber1(Phoneno);
        test.info("User entered Phone/Mobile number: " + Phoneno);
    }

    @And("the user click the submit button")
    public void the_user_click_the_submit_button() {
        test = extent.createTest("Click Submit Button");
        d.submitButton1();
        test.info("User clicked the submit button.");
    }

    @Then("the user should see a success message")
    public void the_user_should_see_a_success_message() {
        String expectedMessage = "Expected success message"; // Replace with actual expected message
        String actualMessage = d.getSuccessMessage();
        Assert.assertEquals(expectedMessage, actualMessage);
        test.pass("User saw the success message: " + actualMessage);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
        extent.flush(); // Flush the report
        log.info("Driver closed and extent report flushed.");
    }
}
