package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pages.RLL_240Testing_Bookswagon.Loginpage;
import com.pages.RLL_240Testing_Bookswagon.MyAddress;

import io.cucumber.java.After;

//import com.pages.RLL_240Tesing_BooksWagon_AddAddress.Loginpage;
//import com.pages.RLL_240Tesing_BooksWagon_AddAddress.MyAddress;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdefinition_MyAddress {

WebDriver driver;
    
   MyAddress ad;
	
   Loginpage lp;
	Logger log;
 
    @Before
    public void init() {
    	driver=new ChromeDriver();
    	ad = new MyAddress(driver);
    	lp= new Loginpage(driver);
    	log= Logger.getLogger(Stepdefinition_MyAddress .class);
    }
    
    @Given("user should in MyAddress page")
    public void user_should_in_MyAddress_page() throws InterruptedException {
    	ad.launch();
        
        driver.navigate().to("https://www.bookswagon.com/myaddress.aspx");
        Thread.sleep(4000);
        log.info("User Accessed Add Address Icon");
 
        
    }
 
    @When("user clicks on AddAddressIcon")
    public void user_clicks_on_AddAddressIcon() {
       ad.AddAddressIcon();
    }
 
    @Then("user can adddetails")
    public void user_can_adddetails() {
    	WebElement text = driver.findElement(By.id("ctl00_phBody_lblheading"));
        Assert.assertTrue(text.isDisplayed(),"Add Address form is not accessible");
        System.out.println("AddressIcon");
    	
    }
    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
    }
}