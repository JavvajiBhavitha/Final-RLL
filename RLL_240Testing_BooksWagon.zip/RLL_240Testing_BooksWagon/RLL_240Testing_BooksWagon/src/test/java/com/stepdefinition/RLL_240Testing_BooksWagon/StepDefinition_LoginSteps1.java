package com.stepdefinition.RLL_240Testing_BooksWagon;

import static org.testng.Assert.assertTrue;
import java.time.Duration;
import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_Bookswagon.LoginPage1;
import com.pages.RLL_240Testing_Bookswagon.homepage;

import io.cucumber.java.After;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class StepDefinition_LoginSteps1 { 

    WebDriver driver;     
    LoginPage1 lp; 
    homepage hp; 
    Logger log1; 
    ExtentReports extent;
    ExtentTest test;

    @Before 
    public void init() {   
        // Initialize ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/LoginSteps1Report.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        driver = new ChromeDriver();  
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        lp = new LoginPage1(driver); 
        hp = new homepage(driver); 
        log1 = Logger.getLogger(StepDefinition_LoginSteps1.class); 
    } 

    @Given("user should be in login page3") 
    public void user_should_be_in_login_page3() { 
        test = extent.createTest("User should be in login page");
        hp.launch(); 
        hp.clickMyAccount(); 
        log1.info("User is in login page"); 
        test.pass("User navigated to the login page");
    } 

    @When("^the user enter mobile or email (.*)$") 
    public void the_user_enter_mobile_or_email(String mobileoremail) { 
        test = extent.createTest("User enters mobile or email");
        lp.enter_mobemail(mobileoremail); 
        test.pass("Entered mobile or email: " + mobileoremail);
    } 

    @When("^user enter passwords (.*)$") 
    public void user_enter_passwords(String password) { 
        test = extent.createTest("User enters password");
        lp.enter_password(password); 
        test.pass("Entered password");
    } 

    @When("user click on login button") 
    public void user_click_on_login_button() { 
        test = extent.createTest("User clicks on login button");
        lp.Click_Login(); 
        test.pass("Clicked on login button");
    } 

    @When("user click on forgot password") 
    public void user_click_on_forgot_password() { 
        test = extent.createTest("User clicks on forgot password");
        lp.ForgotPwdLink(); 
        test.pass("Clicked on forgot password link");
    } 

    @When("user click on request otp") 
    public void user_click_on_request_otp() { 
        test = extent.createTest("User clicks on request OTP");
        lp.ReqOtp(); 
        test.pass("Requested OTP");
    }  

    @When("^I enter otp (.*)$") 
    public void I_enter_otp(String otp1) throws InterruptedException { 
        test = extent.createTest("User enters OTP");
        lp.Enter_ReqOtp(otp1); 
        test.pass("Entered OTP: " + otp1);
    } 

    @When("click on verify")
    public void click_on_verify() {
        test = extent.createTest("User clicks on verify");
        lp.Verify();
        test.pass("Clicked on verify");
    }

    @When("^user enter password1 (.*)$")  
    public void user_enter_new_password1(String forgotpassword) { 
        test = extent.createTest("User enters new password");
        lp.Enter_Forgotpwd(forgotpassword); 
        test.pass("Entered new password");
    } 

    @When("^enter confirm password2 (.*)$") 
    public void enter_confirm_password2(String forgotconfmpassword) { 
        test = extent.createTest("User enters confirm password");
        lp.Enter_ConfmForgotPwd(forgotconfmpassword); 
        test.pass("Entered confirm password");
    } 

    @When("user click login button1") 
    public void user_click_login_button1() { 
        test = extent.createTest("User clicks on login button after forgot password");
        lp.Forgot_LoginButton(); 
        test.pass("Clicked on forgot password login button");
    }

    @Then("user should log in successfully") 
    public void user_should_log_in_successfully() { 
        test = extent.createTest("User should log in successfully");
        String currentUrl = driver.getCurrentUrl();
        assertTrue(currentUrl.contains("https://www.bookswagon.com/login")); 
        test.pass("User logged in successfully. Current URL: " + currentUrl);
    } 

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
        extent.flush(); // Save the report
    }
}
