package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 

public class RemoveItem { 
	WebDriver driver; 

	By carticon = By.id("ctl00_lblTotalCartItems"); 
	By removeButton = By.id("ctl00_phBody_BookCart_lvCart_ctrl0_imgDelete"); 

	public RemoveItem(WebDriver driver) { 
		this.driver = driver; 
	} 
	public void cartIcon() throws InterruptedException { 
		driver.findElement(carticon).click(); 
		Thread.sleep(2000); 
	} 
	public void removeButton() throws InterruptedException { 
		driver.findElement(removeButton).click(); 
		Thread.sleep(2000); 
	} 

} 

