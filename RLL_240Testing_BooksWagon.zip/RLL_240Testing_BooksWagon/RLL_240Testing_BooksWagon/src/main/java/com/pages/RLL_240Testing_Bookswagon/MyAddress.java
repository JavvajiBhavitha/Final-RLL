package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyAddress {

	By Add_address=By.xpath("//a[@href=\"addaddress.aspx\"]");
	WebDriver driver;
	public MyAddress(WebDriver driver) {
		this.driver = driver;	}
	
	public void launch() throws InterruptedException {
		
		driver.get("https://www.bookswagon.com/");
		Thread.sleep(3000);
		//driver.navigate().to("https://www.bookswagon.com/myaddress.aspx");
		
		
		
	}
	public void AddAddressIcon() {
		driver.findElement(Add_address).click();
		
	}
}