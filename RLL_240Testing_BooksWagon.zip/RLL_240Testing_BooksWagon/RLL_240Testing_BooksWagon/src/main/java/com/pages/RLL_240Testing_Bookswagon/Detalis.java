package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Detalis {
    WebDriver driver;

    By ISBN13 = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtISBN']");
    By Author = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtAuthor']");
    By emailField1 = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtEmailReq']");
    By verifyEmailButton = By.xpath("//input[@id='ctl00_phBody_RequestBook_btnVeiry']");
    By BookTitle1 = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtTitle']");
    By Quantity = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtQty']");
    By phoneNumber1 = By.xpath("//input[@id='ctl00_phBody_RequestBook_txtPhone']");
    By submitButton1 = By.xpath("//input[@id='ctl00_phBody_RequestBook_imgbtnSave']");
    By errorMessage = By.xpath("//input[@id='ctl00_phBody_RequestBook_lblsuccessmsg']");

    public void init1(WebDriver driver) {
    	
        this.driver = driver;
        driver.get("https://www.bookswagon.com/requestbook");
    }

    public void ISBN13(String ISBN13no) {
        driver.findElement(ISBN13).sendKeys(ISBN13no);
    }

    public void Author(String Authorname) {
        driver.findElement(Author).sendKeys(Authorname);
    }

    public void emailField1(String Emaild) {
        driver.findElement(emailField1).sendKeys(Emaild);
    }

    public void verifyEmailButton() {
        driver.findElement(verifyEmailButton).click();
    }

    public void BookTitle(String BookTitle) {
        driver.findElement(BookTitle1).sendKeys(BookTitle);
    }

    public void Quantity(String BookQunatity) {
        driver.findElement(Quantity).sendKeys(BookQunatity);
    }

    public void phoneNumber1(String Phoneno) {
        driver.findElement(phoneNumber1).sendKeys(Phoneno);
    }

    public void submitButton1() {
        driver.findElement(submitButton1).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(errorMessage).getText();
    }
}
