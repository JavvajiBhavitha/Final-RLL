package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class AddingAddress {



	By Fullname=By.xpath("//input[@name=\"ctl00$phBody$ShippingAddress$txtRecipientName\"]");
	By CompanyName=By.xpath("//input[@id=\"ctl00_phBody_ShippingAddress_txtCompanyName\"]");
	By Street_Address=By.xpath("//input[@name=\"ctl00$phBody$ShippingAddress$txtAddress\"]");
	By Landmark=By.xpath("//input[@id=\"ctl00_phBody_ShippingAddress_txtLandmark\"]");
	By country=By.xpath("//*[@name=\"ctl00$phBody$ShippingAddress$ddlCountry\"]");
	By state=By.xpath("//select[@name=\"ctl00$phBody$ShippingAddress$ddlState\"]");
	By city=By.id("ctl00_phBody_ShippingAddress_ddlCities");
	By pin_Zip_code=By.xpath("//input[@id=\"ctl00_phBody_ShippingAddress_txtPincode\"]");
	By Mobile=By.xpath("//input[@id=\"ctl00_phBody_ShippingAddress_txtMobile\"]");
	By Phone=By.xpath("//input[@id=\"ctl00_phBody_ShippingAddress_txtPhone\"]");
	By checkbox=By.xpath("//input[@type=\"checkbox\"]");
	By Update=By.xpath("//a[@id=\"ctl00_phBody_ShippingAddress_imgSubmit\"]");
	By cancel=By.xpath("//*[@class=\"cancelsetting\"]");
	WebDriver driver;
	Select select;
	public AddingAddress (WebDriver driver) {
		this.driver=driver;
	}
	public void Launch_App() throws InterruptedException {
		driver.get("https://www.bookswagon.com/");
		Thread.sleep(2000);
		Thread.sleep(4000);
}
	public void Fullname(String Full_Name)
	{
	driver.findElement(Fullname).sendKeys(Full_Name);
	}
	public void CompanyName(String Company_Name) {
		driver.findElement(CompanyName).sendKeys(Company_Name);
	}
	public void StreetAddress(String Streert_Address) {
	driver.findElement(Street_Address).sendKeys(Streert_Address);
	}
	public void Landmark(String Land_mark) {
		driver.findElement(Landmark).sendKeys(Land_mark);
	}
	public void Country(String Country) {
		driver.findElement(country).sendKeys(Country);
		WebElement dropdown=driver.findElement(country);
		select =new Select(dropdown);
		select.selectByValue("India");
	}
	public void State ( String State) throws InterruptedException {
		WebElement dropdown1=driver.findElement(state);
		select =new Select(dropdown1);
		select.selectByValue("Andhra Pradesh");
		Thread.sleep(2000);
	}
	public void selectcity(String City) throws InterruptedException {
	WebElement dropdown2=driver.findElement(city);
	select =new Select(dropdown2);
	select.selectByValue("Adoni");
	Thread.sleep(1000);
	}
	public  void Zipcode(String Zip_Code) {
	driver.findElement(pin_Zip_code).sendKeys(Zip_Code);
	}
	public void Mobile(String Mobile_no) {
		driver.findElement(Mobile).sendKeys(Mobile_no);
	}
	public void phone(String phone_no) {
		driver.findElement(Phone).sendKeys(phone_no);
	}
	public void checkbox() {
		driver.findElement(checkbox).click();
	}
	public void Update() {
		driver.findElement(Update).click();
		
	}
}
 
 
 
 


