package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Loginpage {
	WebDriver driver;

	By signuplink = By.xpath("/html/body/form/div[10]/div/div/div/div/div[2]/div[1]/div[4]/div/a");
	By otpField = By.name("ctl00$phBody$SignUp$txtOTP");
	By passwordField = By.name("ctl00$phBody$SignUp$txtPassword");
	By confirmPasswordField = By.name("ctl00$phBody$SignUp$txtConfirmPwd");
	By signUpButton = By.id("ctl00_phBody_SignUp_btnSubmit");


	public Loginpage(WebDriver driver) {
		this.driver = driver;
	}
	public void clickSignUpLink() {
		driver.findElement(signuplink).click();
	}
	public void enterOtp(String otp) {
		WebElement otpElement = driver.findElement(otpField);
		otpElement.clear();
		otpElement.sendKeys(otp);
	}
	public void enterPassword(String pwd) throws InterruptedException {
		WebElement passwordElement = driver.findElement(passwordField);
		passwordElement.clear();
		passwordElement.sendKeys(pwd);
		Thread.sleep(3000);
	}
	public void enterConfirmPassword(String confirmpwd) throws InterruptedException {
		WebElement confirmPasswordElement = driver.findElement(confirmPasswordField);
		confirmPasswordElement.clear();
		confirmPasswordElement.sendKeys(confirmpwd);
		Thread.sleep(3000);
	}
	public void clickSignUpButton() throws InterruptedException {
		driver.findElement(signUpButton).click();
		Thread.sleep(3000);
	}


}
