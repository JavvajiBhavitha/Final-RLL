package com.pages.RLL_240Testing_Bookswagon; 

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.support.ui.ExpectedConditions; 
import org.openqa.selenium.support.ui.WebDriverWait; 
import java.time.Duration; 

public class AwardWinnersPage { 
    WebDriver driver; 

    By awardWinnersSection = By.xpath("//a[contains(text(), 'Award Winners')]"); 

    public AwardWinnersPage(WebDriver driver) { 
        this.driver = driver; 
    } 

    public void launch() { 
        driver.get("https://www.bookswagon.com/promo-best-seller/award-winning/2109CDC4B4DC"); 
        driver.manage().window().maximize();
    } 

    public void navigateToAwardWinners() { 
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
        wait.until(ExpectedConditions.elementToBeClickable(awardWinnersSection)).click(); 
        System.out.println("User clicked Award Winners"); 
    } 

    public boolean isAwardWinnersDisplayed() { 
        return driver.getTitle().contains("Award Winners"); 
    } 
    
    public void isCorrectPageDisplayed() {
    	 String currentUrl = driver.getCurrentUrl(); 
         String expectedUrl = "https://www.bookswagon.com/promo-best-seller/award-winning/2109CDC4B4DC";
         if (!currentUrl.equals(expectedUrl)) { 
             throw new AssertionError("User did not navigate to home page. Current URL: " + currentUrl); 
         } 
         System.out.println("User successfully in award Winners section"); 
     }   
}
