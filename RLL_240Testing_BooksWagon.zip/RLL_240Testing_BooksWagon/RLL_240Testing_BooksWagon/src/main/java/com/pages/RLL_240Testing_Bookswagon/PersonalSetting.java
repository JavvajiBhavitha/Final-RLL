package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class PersonalSetting {


	WebDriver driver;
	By perssett =By.xpath("//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[1]/div/a");
	
	public PersonalSetting(WebDriver driver)  {
		this.driver = driver;
	}
	
	public void launch() {
		
		driver.get("https://www.bookswagon.com/");
		
		
	}
	public void click_personalSettingsButton() {
		

		driver.findElement(perssett).click();
	}
}



